import { Component } from '@angular/core';

@Component({
  selector: 'app-incubators',
  templateUrl: './incubators.component.html',
  styleUrls: ['./incubators.component.css']
})
export class IncubatorsComponent {

}
