import { Component } from '@angular/core';

@Component({
  selector: 'app-facilites',
  templateUrl: './facilites.component.html',
  styleUrls: ['./facilites.component.css']
})
export class FacilitesComponent {

}
